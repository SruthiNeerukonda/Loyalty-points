# flask_app.py (Place this file in the project root)
import os
from flask import Flask, jsonify, request, g
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import SQLAlchemyError
flask_app = Flask(__name__, static_folder='../static', template_folder='../templates')
# --- Import shared components from the 'app' package ---
# Assumes running from the project root directory
try:
    from app.database import SessionLocal, engine, Base # Get Session factory and Base
    from app.models import Item # Import specific models needed by Flask routes
    # from app.models import User, Coupon # etc.
    DB_COMPONENTS_LOADED = True
    print("Successfully imported DB components into flask_app.")
except ImportError as e:
    print(f"Error importing DB components into flask_app: {e}")
    DB_COMPONENTS_LOADED = False
    # Define dummies if import fails to prevent Flask startup errors,
    # though the routes using them will fail later.
    SessionLocal = None
    Base = None
    Item = None


# --- Initialize Flask App ---
# Use a distinct name, especially if debugging/logging
flask_app = Flask(__name__.split('.')[0]) # e.g., 'flask_app'

# --- Create Database Tables (Development/Initial Setup ONLY) ---
# Use Alembic migrations for production environments!
# Comment this out once you use Alembic migrations.
# print("Flask App: Attempting to create database tables (if needed)...")
# if DB_COMPONENTS_LOADED and Base and engine:
#     try:
#         Base.metadata.create_all(bind=engine)
#         print("Flask App: Finished create_all().")
#     except Exception as e:
#         print(f"Flask App: Error during create_all(): {e}")
# else:
#     print("Flask App: DB Components not loaded, skipping create_all().")
# --------------------------------------------------------------
@flask_app.route('/') # Route for the root path served by Flask
def index_flask():
     # Looks for index.html inside the 'templates' folder
     return render_template('index.html')

# --- Database Session Management for Flask Requests ---
@flask_app.before_request
def before_request_callback():
    """Create a database session for each request."""
    if SessionLocal:
        g.db = SessionLocal() # Store session in Flask's request context 'g'
        print(f"[Flask Request {request.path}] DB Session opened.")
    else:
        g.db = None
        print(f"[Flask Request {request.path}] DB Session NOT opened (SessionLocal unavailable).")


@flask_app.teardown_request
def teardown_request_callback(exception=None):
    """Close the database session after each request."""
    db = g.pop('db', None) # Retrieve session from 'g'
    if db is not None:
        try:
            # Optional: Rollback if an exception occurred during the request
            if exception:
                print(f"[Flask Request {request.path}] Exception detected, rolling back DB session.")
                db.rollback()
            else:
                # You might commit here if you structure commits differently,
                # but generally commits happen within the route handler.
                pass
            db.close()
            print(f"[Flask Request {request.path}] DB Session closed.")
        except SQLAlchemyError as e:
            print(f"[Flask Request {request.path}] Error closing DB session: {e}")
            # Potentially handle session closing errors more robustly
    else:
         print(f"[Flask Request {request.path}] No DB Session found in 'g' to close.")


# --- Example Flask Routes ---
@flask_app.route('/flask_items', methods=['GET'])
def get_items_flask():
    """Gets a list of example items using Flask."""
    if not g.db:
        return jsonify({"error": "Database session not available"}), 500

    db: Session = g.db
    try:
        items = db.query(Item).limit(10).all()
        # Manually convert ORM objects to dictionaries for JSON serialization
        items_data = [{"id": item.id, "name": item.name, "description": item.description}
                      for item in items]
        return jsonify(items_data)
    except SQLAlchemyError as e:
        print(f"Error querying items in Flask: {e}")
        return jsonify({"error": "Database query failed"}), 500
    except AttributeError:
         # If Item model wasn't loaded correctly
         return jsonify({"error": "Item model not available"}), 500


@flask_app.route('/flask_items', methods=['POST'])
def create_item_flask():
    """Creates an example item using Flask."""
    if not g.db:
        return jsonify({"error": "Database session not available"}), 500

    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({"error": "Missing 'name' in request body"}), 400

    db: Session = g.db
    try:
        new_item = Item(name=data['name'], description=data.get('description'))
        db.add(new_item)
        db.commit()
        db.refresh(new_item) # Get ID, defaults, etc.
        # Return the created item's data
        return jsonify({
            "id": new_item.id,
            "name": new_item.name,
            "description": new_item.description,
            "created_at": new_item.created_at.isoformat() if new_item.created_at else None
            # Add other relevant fields
        }), 201 # Created status code
    except SQLAlchemyError as e:
        db.rollback() # Rollback on error
        print(f"Error creating item in Flask: {e}")
        return jsonify({"error": "Database operation failed"}), 500
    except AttributeError:
         db.rollback()
         return jsonify({"error": "Item model not available"}), 500


@flask_app.route('/flask_health')
def flask_health_check():
    """Simple health check endpoint for the Flask portion."""
    db_status = "Unavailable"
    if g.get('db'): # Check if db was successfully added to g
        try:
            # Perform a simple query to check DB connection
            g.db.execute("SELECT 1")
            db_status = "OK"
        except Exception as e:
            db_status = f"Error: {e}"

    return jsonify({"status": "Flask App OK", "database_connection": db_status})

# Add more Flask routes here...

# Note: This file is NOT run directly with 'flask run' when mounted.
# It's imported and handled by the ASGI server (Uvicorn) running main.py.