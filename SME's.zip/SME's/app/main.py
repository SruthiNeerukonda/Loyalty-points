# app/main.py
import os
from fastapi import FastAPI, Depends, HTTPException, Request # Request might be needed if using Jinja2 later
from fastapi.middleware.wsgi import WSGIMiddleware
from fastapi.staticfiles import StaticFiles # <--- ADD THIS IMPORT
from fastapi.responses import FileResponse # Keep if serving index.html directly
# from fastapi.templating import Jinja2Templates # Keep commented if not using Jinja2 yet
from sqlalchemy.orm import Session

# --- Import shared components from within the 'app' package ---
from .database import engine, Base, get_db # Use relative imports
from . import models, schemas             # Import models and schemas

# --- Import routers ---
# from .routers import items

# --- Import the Flask app instance (from the root level file) ---
try:
    from flask_app import flask_app
    FLASK_APP_LOADED = True
    print("Successfully imported flask_app.")
except ImportError:
    print("Warning: Could not import flask_app. Flask endpoints will not be mounted.")
    FLASK_APP_LOADED = False
    flask_app = None

# --- Create Database Tables (Development/Initial Setup ONLY) ---
# print("Attempting to create database tables...")
# Base.metadata.create_all(bind=engine)
# print("Finished create_all().")

# --- Initialize FastAPI App ---
app = FastAPI(
    title="Customer Portal Pro API",
    description="API for managing customer loyalty, coupons, and receipts.",
    version="0.1.0",
)

# --- Mount Static Files ---
# Make sure the 'static' directory exists at your project root!
# (where you run uvicorn from)
try:
    if not os.path.isdir("static"):
         print("Warning: 'static' directory not found at project root. Creating it.")
         os.makedirs("static") # Create directory if it doesn't exist
    app.mount("/static", StaticFiles(directory="static"), name="static") # <-- This line should now work
    print("Mounted static directory at /static")
except Exception as e:
    print(f"Error mounting static directory: {e}")


# --- Mount the Flask App (if loaded successfully) ---
# (Keep this section as is)
if FLASK_APP_LOADED and flask_app:
    app.mount("/flask", WSGIMiddleware(flask_app))
    print(f"Flask app '{flask_app.name}' mounted under /flask prefix.")
else:
    print("Flask app not mounted.")


# --- Serve index.html (Optional - choose one method or none) ---
# Make sure the 'templates' directory exists at your project root!
# Option 1: Direct FileResponse
try:
    if not os.path.isdir("templates"):
        print("Warning: 'templates' directory not found at project root. Cannot serve index.html directly.")
    else:
        @app.get("/", include_in_schema=False) # Route for the root path
        async def serve_index():
            # Path is relative to where you RUN uvicorn
            index_path = 'templates/index.html'
            if not os.path.exists(index_path):
                raise HTTPException(status_code=404, detail="index.html not found")
            return FileResponse(index_path)
        print("Configured root route '/' to serve templates/index.html")
except Exception as e:
    print(f"Error configuring root route for index.html: {e}")
@app.get("/customers", include_in_schema=False) # Define the route /customers
async def serve_customers_page():
    customers_path = 'templates/customers.html'
    if not os.path.exists(customers_path):
        raise HTTPException(status_code=404, detail="customers.html not found")
    # Path is relative to where you RUN uvicorn (project root)
    return FileResponse(customers_path)
print("Configured route '/customers' to serve templates/customers.html via FileResponse")
# Option 2: Jinja2 Templates (Requires installing jinja2: pip install jinja2)
# from fastapi.templating import Jinja2Templates
# templates = Jinja2Templates(directory="templates")
# @app.get("/", include_in_schema=False)
# async def serve_index_template(request: Request):
#     return templates.TemplateResponse("index.html", {"request": request})


# --- Include FastAPI Routers ---
# app.include_router(items.router)

# --- Example FastAPI Root Endpoint (if not serving index.html) ---
# Comment this out if you serve index.html from the root "/"
# @app.get("/", include_in_schema=False) # Default root if not serving HTML
# async def read_root():
#     """Provides a welcome message for the API root."""
#     return {"message": "Welcome to the Customer Portal Pro API! (Root)"}

# --- Example API Endpoints ---
# (Keep your other example endpoints or real routers)
@app.get("/fastapi_items_example/", response_model=list[schemas.Item], tags=["Examples"])
def get_fastapi_items_example(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    # ... implementation ...
    items = db.query(models.Item).offset(skip).limit(limit).all()
    return items

@app.post("/fastapi_items_example/", response_model=schemas.Item, status_code=201, tags=["Examples"])
def create_fastapi_item_example(item: schemas.ItemCreate, db: Session = Depends(get_db)):
    # ... implementation ...
    db_item = models.Item(**item.dict())
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item

# --- Application Lifecycle Events ---
# (Keep these as is)
@app.on_event("startup")
async def startup_event():
    print("FastAPI application starting up...")
    print("FastAPI startup complete.")

@app.on_event("shutdown")
async def shutdown_event():
    print("FastAPI application shutting down...")
    print("FastAPI shutdown complete.")