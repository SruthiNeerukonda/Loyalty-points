# app/schemas.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# Base schema with common fields
class ItemBase(BaseModel):
    name: str
    description: Optional[str] = None

# Schema for creating an item (inherits from Base)
class ItemCreate(ItemBase):
    pass # No extra fields needed for creation in this simple case

# Schema for reading an item (includes fields from DB like id, created_at)
class Item(ItemBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        orm_mode = True # Allows Pydantic to read data from ORM models