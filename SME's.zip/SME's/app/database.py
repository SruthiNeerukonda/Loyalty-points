# database.py
import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

load_dotenv() # Load variables from .env file for local development

# Get the database URL from environment variable
SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL")

if SQLALCHEMY_DATABASE_URL and SQLALCHEMY_DATABASE_URL.startswith("postgres://"):
     # Heroku's DATABASE_URL starts with postgres:// but SQLAlchemy needs postgresql://
     SQLALCHEMY_DATABASE_URL = SQLALCHEMY_DATABASE_URL.replace("postgres://", "postgresql://", 1)
elif not SQLALCHEMY_DATABASE_URL:
    # Fallback or error handling if URL not set
    print("DATABASE_URL environment variable not set.")
    # You might want to raise an exception or use a default SQLite DB for local dev
    # For example: SQLALCHEMY_DATABASE_URL = "sqlite:///./sql_app.db"
    exit(1) # Exit if database URL is critical and not found


# Create the SQLAlchemy engine
# connect_args is useful for SQLite, generally not needed for Postgres
# pool_pre_ping helps handle stale connections
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, pool_pre_ping=True
)

# Create a SessionLocal class - each instance will be a database session
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for our ORM models
Base = declarative_base()

# Dependency (useful for FastAPI, can be adapted for Flask)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

print(f"Database engine created for URL ending with: ...{SQLALCHEMY_DATABASE_URL[-20:]}")