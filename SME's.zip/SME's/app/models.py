# models.py
from sqlalchemy import Column, Integer, String, DateTime, func
from .database import Base # Import Base from our database setup

class Item(Base):
    __tablename__ = "items" # Table name in the database

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

# Add other models here (e.g., User, Coupon, Receipt)
# Example:
# class User(Base):
#    __tablename__ = "users"
#    id = Column(Integer, primary_key=True)
#    email = Column(String, unique=True, index=True)
#    points = Column(Integer, default=0)